package ch06.exam05;

public class Member {
	//Field
	String name;
	int age;
	//Constructor
	Member(String name, int age){
		this.name = name;
		this.age = age;
	}
	//Method
}
