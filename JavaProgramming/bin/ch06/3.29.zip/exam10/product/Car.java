package ch06.exam10.product;

//import ch06.exam10.parts.Engine;
//import ch06.exam10.parts.Tire;
import ch06.exam10.parts.*;
import ch06.exam10.parts2.*;

public class Car {
	Engine engine = new Engine();
	ch06.exam10.parts2.Tire tire = new ch06.exam10.parts2.Tire();
}
