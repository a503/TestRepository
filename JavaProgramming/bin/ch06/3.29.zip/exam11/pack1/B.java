package ch06.exam11.pack1;

public class B {
	A a = new A();
	
	void method(){
		a.field1 = 10;
		//a.method();
	}
}
 