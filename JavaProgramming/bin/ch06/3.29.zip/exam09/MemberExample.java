package ch06.exam09;

public class MemberExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Member member = new Member("ȫ�浿","123123-1231231");
		member.name = "ȫö";
		
	}

}
