package ch06.homework03;

public class Calculator {
	static double pi = 3.14159;
	
	static int plus(int x, int y){
		return x + y;
	}
	
	static int minux(int x, int y){
		return x - y;
	}
}
