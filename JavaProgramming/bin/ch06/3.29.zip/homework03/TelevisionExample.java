package ch06.homework03;

public class TelevisionExample {

	public static void main(String[] args) {
		System.out.println(Television.info);

	}

}
