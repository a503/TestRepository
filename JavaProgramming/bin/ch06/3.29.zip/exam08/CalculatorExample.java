package ch06.exam08;

public class CalculatorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator calc1 = Calculator.getInstance();
		Calculator calc2 = Calculator.getInstance();
		Calculator calc3 = Calculator.getInstance();
		Calculator calc4 = Calculator.getInstance();
		
	}

}
