package ch07.exam07.homework07_1._2;
// �θ� ������ ȣ��,super()
public class People {
	public String name;
	public String ssn;
	
	public People(String name, String ssn){
		this.name = name;
		this.ssn = ssn;
	}
}
