package ch07.exam07.homework07_1._5;

final public class Member {

}
